# CTA buttons — what changed, and the one thing you need to do

## What changed

Each bundle tier now has its own checkout button. Before, all three tiers shared a single
button pointing at one product URL, so a buyer couldn't pick a bundle and you had nowhere
to wire the three offers.

Three files, each with two offer blocks (mid-page and end-of-page), three buttons per block:

- `page-2.html`
- `v6-page-2.html`
- `v7-page-2.html`

The old shared button underneath the tiers is gone. The guarantee/free-shipping line under
the tiers stays.

## The one thing you need to do

The three buttons point at placeholders:

```
#REPLACE-WITH-1-BOTTLE-CHECKOUT-URL
#REPLACE-WITH-3-BOTTLE-CHECKOUT-URL
#REPLACE-WITH-6-BOTTLE-CHECKOUT-URL
```

They are deliberately obvious. A wrong variant ID silently sends buyers to the wrong
product, which is worse than a link that visibly does nothing.

### Why they aren't filled in

Checked against your live store on 2026-08-14:

- The product the funnel points at (`cbd-oil-drops-kids-350mg-bogo-sale`) has **one**
  variant — `52672665420098`, $69.99.
- There is **no 3-bottle or 6-bottle kids-oil product** anywhere in the catalogue (checked
  all 48 products).
- The page prices — $69 / $149 / $269 — don't exist on the store in any form.

So the bundles the page sells aren't SKUs yet. That's the blocker.

### How to fix it

1. **Create the 3-pack and 6-pack products in Shopify**, priced $149 and $269.

   The pattern already exists in your store — your gummies use a single product with a
   "Stock Up and Save" option (Single jar / 2 jars / 3 jars), each its own variant. Copy
   that. One product, three variants, is cleaner than three separate products.

2. **Grab each variant ID.** Easiest way: open

   ```
   https://www.greenvalleynutrition.com/products/<your-handle>.json
   ```

   and read the `variants` array. Each entry has an `id`.

3. **Build the cart permalinks:**

   ```
   https://www.greenvalleynutrition.com/cart/<VARIANT_ID>:1
   ```

4. **Find-and-replace** each placeholder with its real URL. Six replacements per file
   (two offer blocks x three tiers), three files.

### If you want the buttons live before the bundles exist

You can point all three at the existing single bottle with a quantity:

```
https://www.greenvalleynutrition.com/cart/52672665420098:1
https://www.greenvalleynutrition.com/cart/52672665420098:3
https://www.greenvalleynutrition.com/cart/52672665420098:6
```

Verified working — `:3` lands 3 bottles in a real cart. **But** it charges 3 x $69.99 =
$209.97, not the $149 the page promises. Only use this as a stopgap, and fix the page
prices to match if you do.

## Note on the other funnel

The sleepy-night CBN funnel currently live has three dead variant IDs in its bundle
buttons (`46820171694261`, `46820171727029`, `46820171759797`). None of them exist in the
catalogue anymore — the current CBN gummy variants are `50979944268098`,
`50979944300866`, `50979944333634`. Worth fixing whenever you're next in there.

## Images

The `images/` folder holds the four product shots the pages use (1 / 3 / 6 bottle tiers
plus the BOGO shot).

Inside the HTML they're referenced by absolute path:

```
/clients/ethan-pompeo-gvn/codex-funnel-2026-07-27/funnel/images/kids-cbd-3bottles.png
```

That path only resolves on our preview server. When you rebuild in GHL, upload the four
images and point the `src` attributes at wherever GHL hosts them. If you just want to open
the files locally to look at them, find-replace that path prefix with `images/`.
